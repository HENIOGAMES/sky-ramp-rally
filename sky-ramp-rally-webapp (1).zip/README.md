# Sky Ramp Rally

Race chubby skaters down a giant ramp in the sky. Dodge giant crates and cannonballs, grind rails, land tricks and finish on the podium to unlock the next stage.

## Put it on GitHub Pages

1. Create a new public repository on GitHub (for example `sky-ramp-rally`).
2. Upload **all the files in this folder** to the root of the repository (Add file → Upload files), then commit.
3. Open **Settings → Pages**, set **Source** to *Deploy from a branch*, choose the `main` branch and the `/ (root)` folder, and save.
4. After a minute your game is live at `https://YOUR-USERNAME.github.io/sky-ramp-rally/`.

## Install it as an app

- **iPhone / iPad (Safari):** open the link, tap **Share → Add to Home Screen**.
- **Android (Chrome):** open the link, tap the **⋮** menu → **Install app** (or *Add to Home screen*).
- **Desktop Chrome / Edge:** click the install icon in the address bar.

It opens full screen with its own icon, and after the first visit it also works offline.

## Controls

Keyboard: **A/D** steer · **S** brake · **Space** jump · **1/J** kickflip · **2/K** grab (hold) · **3/L** grind (hold) · **Shift** boost
Touch: slider to steer, buttons for the tricks.
